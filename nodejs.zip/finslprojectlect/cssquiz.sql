-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 16, 2019 at 07:11 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cssquiz`
--
CREATE DATABASE IF NOT EXISTS `cssquiz` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cssquiz`;

-- --------------------------------------------------------

--
-- Table structure for table `answerandchoices`
--

DROP TABLE IF EXISTS `answerandchoices`;
CREATE TABLE IF NOT EXISTS `answerandchoices` (
  `id` int(11) NOT NULL,
  `correctanswer` int(1) DEFAULT NULL,
  `numberofquestions` int(11) DEFAULT NULL,
  `answertext` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answerandchoices`
--

INSERT INTO `answerandchoices` (`id`, `correctanswer`, `numberofquestions`, `answertext`) VALUES
(1, 0, 1, 'Cascade Style Sheet'),
(2, 0, 1, 'Creating Style Sheet'),
(3, 1, 1, 'Cascading Style Sheet'),
(4, 0, 2, 'Tim Berners-Lee'),
(5, 1, 2, 'Hakon Wium Lee'),
(6, 0, 2, 'Bert Bos'),
(7, 0, 2, 'b and c'),
(8, 0, 3, 'Eternal, Inline, Embedded'),
(9, 1, 3, 'External, Internal, Inline'),
(10, 0, 3, 'External, Internal, Embedded'),
(11, 0, 3, 'Eternal, Internal, Inline'),
(12, 1, 4, 'p{color:blue;}'),
(13, 0, 4, '{p:color = blue;}'),
(14, 0, 4, 'p:{\"color = blue\";}'),
(15, 0, 5, 'Application'),
(16, 0, 5, 'Session'),
(17, 1, 5, 'Presentation'),
(18, 0, 6, 'style'),
(19, 1, 6, 'selector'),
(20, 0, 6, 'property'),
(21, 0, 6, 'declaration'),
(22, 0, 7, '//This is a single comment'),
(23, 0, 7, '<!--This is a single comment->'),
(24, 0, 7, '//This is a single comment//'),
(25, 1, 7, '/*This is a single comment*/'),
(26, 0, 8, 'It combines same style into one declaration block'),
(27, 0, 8, 'It is used to combine 2 or more elements.'),
(28, 1, 8, 'It will select all matched elements in the document.'),
(29, 0, 9, 'Class Selector'),
(30, 0, 9, 'Group Selector'),
(31, 1, 9, 'ID Selector'),
(32, 0, 10, '@charset'),
(33, 1, 10, '@supports'),
(34, 0, 10, '@import'),
(35, 1, 11, 'It allows authors set several property value in a single line.'),
(36, 0, 11, 'It allows authors to write property values faster.'),
(37, 0, 11, 'It allows authors to use a specific property value that can be used again.'),
(38, 0, 12, '-webkit-'),
(39, 1, 12, '-mz-'),
(40, 0, 12, '-o-'),
(41, 0, 13, 'It is made up of two or more selectors but separated by \">\".'),
(42, 0, 13, 'It is made up of two or more selectors but separated by \"<\".'),
(43, 1, 13, 'It is made up of two or more selectors with whitespace between two selectors.'),
(44, 0, 14, 'Value Selectors'),
(45, 0, 14, 'Type Selectors'),
(46, 1, 14, 'Attribute Selectors'),
(47, 0, 15, ':first-letter'),
(48, 1, 15, ':first-number'),
(49, 0, 15, ':first-line'),
(50, 0, 16, 'It used by browser vendors as a prefix for the names of experimental or non-standard CSS properties.'),
(51, 1, 16, 'Property names prefixed with \"- -\", that contains a specific value that can be used again in every part of the document.'),
(52, 0, 16, 'It allows authors set several property value in a single line.'),
(53, 0, 17, 'It is used to control the presentation of the webpage.'),
(54, 1, 17, 'It is used to identify selectors that can be attached with other selectors.'),
(55, 0, 17, 'It is used as a guideline in styling the content. '),
(56, 0, 18, 'Inline'),
(57, 1, 18, 'Internal'),
(58, 0, 18, 'Linked'),
(59, 1, 19, 'It is made up of two or more selectors but separated by \">\".'),
(60, 0, 19, 'It is made up of two or more selectors but separated by \"~\".'),
(61, 0, 19, 'It is made up of two or more selectors but separated by \"+\".'),
(62, 0, 20, 'CSS variables'),
(63, 1, 20, 'Vendor specific extensions'),
(64, 0, 20, 'Shorthand Properties');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `numberofquestions` int(11) NOT NULL,
  `questions` text,
  PRIMARY KEY (`numberofquestions`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`numberofquestions`, `questions`) VALUES
(1, 'What does CSS stands for?'),
(2, 'Who proposed CSS?'),
(3, 'What are the 3 ways to apply CSS style to a HTML document?'),
(4, 'Which is the correct CSS syntax?'),
(5, 'Which layer does the CSS controls?'),
(6, 'What HTML tag is used in CSS rule to determine which style will be applied?'),
(7, 'How to insert comment in a CSS file?'),
(8, 'What is Type Selectors?'),
(9, 'Which selector is preceded by a number sign(#)?'),
(10, 'Which is an example of Nested Statement?'),
(11, 'What is a Shorthand Properties?'),
(12, 'Which is NOT an example of Vendor specific extensions?'),
(13, 'What is a Descendant Selectors?'),
(14, 'It is used to style elements based on values or attributes.'),
(15, 'Which is NOT an example of Pseudo-Classes?'),
(16, 'What is a Custom Properties?'),
(17, 'What is the use of Rule Set?'),
(18, 'Which stylesheet is specified within the HEAD tag of HTML?'),
(19, 'What is Child Selector?'),
(20, 'It is used as a prefix for the names of non-standard CSS properties.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
