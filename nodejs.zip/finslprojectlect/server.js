var mysql = require('mysql');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');


app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs');

var connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: '',
	database: 'cssquiz'
});


var server = app.listen(4000,function(){
	console.log('Server is online')
});

app.get('/', function(req, res) {
	connection.query('SELET * FROM questions', function(err, result){
			res.render('pages/index',{
			items: result
		})
	}) 
});
